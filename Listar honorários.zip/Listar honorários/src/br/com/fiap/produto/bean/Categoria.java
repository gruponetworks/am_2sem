package br.com.fiap.produto.bean;

import java.util.Calendar;

public class Categoria {

	private int codigo;
	
	private String titulo;
	
	private String descricao;
	
	private Calendar dataCadastro;
	
	public Categoria() {
		super();
	}

	public Categoria(String titulo, String descricao,
			Calendar dataCadastro) {
		super();
		this.titulo = titulo;
		this.descricao = descricao;
		this.dataCadastro = dataCadastro;
	}
	
	public Categoria(int codigo, String titulo, String descricao,
			Calendar dataCadastro) {
		super();
		this.codigo = codigo;
		this.titulo = titulo;
		this.descricao = descricao;
		this.dataCadastro = dataCadastro;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Calendar getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(Calendar dataCadastro) {
		this.dataCadastro = dataCadastro;
	}
	
}
