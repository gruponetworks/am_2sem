package br.com.fiap.produto.bean;

import java.util.Calendar;

public class Produto {

	public Produto() {
		super();
	}

	public Produto(String descricao, double preco, int estoque,
			String categoria, String subcategoria, Calendar dataCadastro) {
		super();
		this.descricao = descricao;
		this.preco = preco;
		this.estoque = estoque;
		this.categoria = categoria;
		this.subcategoria = subcategoria;
		this.dataCadastro = dataCadastro;
	}

	private int codigo;
	
	private String descricao;
	
	private double preco;
	
	private int estoque;
	
	private String categoria;
	
	private String subcategoria;
	
	private Calendar dataCadastro;

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public int getEstoque() {
		return estoque;
	}

	public void setEstoque(int estoque) {
		this.estoque = estoque;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getSubcategoria() {
		return subcategoria;
	}

	public void setSubcategoria(String subcategoria) {
		this.subcategoria = subcategoria;
	}

	public Calendar getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(Calendar dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

}
