package br.com.fiap.produto.bo;

import java.util.List;

import br.com.fiap.produto.bean.Produto;
import br.com.fiap.produto.dao.ProdutoDAO;

public class ProdutoBO {

	private ProdutoDAO dao = new ProdutoDAO();
	
	public void cadastrar(Produto p) throws Exception{
		if (p.getDescricao() == null || p.getDescricao().isEmpty())
			throw new Exception("Nome � obrigat�rio");
		dao.cadastrar(p);
	}
	
	public Produto buscarPorCodigo(int codigo){
		 return dao.buscarPorCodigo(codigo);
	}
	
	public void alterar(Produto p) throws Exception{
		if (p.getDescricao() == null || p.getDescricao().isEmpty())
			throw new Exception("Nome � obrigat�rio");
		dao.alterar(p);
	}
	
	public void remover(int codigo) throws Exception{
		dao.remover(codigo);
	}
	
	public List<Produto> buscarTodos(){
		return dao.buscarTodos();
	}
	
	public List<Produto> buscarPorDescricao(String desc){
		return dao.buscarPorDescricao(desc);
	}
	
}
