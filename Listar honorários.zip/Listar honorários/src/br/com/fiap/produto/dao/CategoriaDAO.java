package br.com.fiap.produto.dao;

import java.util.ArrayList;
import java.util.List;

import br.com.fiap.produto.bean.Categoria;

public class CategoriaDAO {

	private static List<Categoria> lista =
			new ArrayList<Categoria>();
	
	private static int  sequence=0;
	
	public void cadastrar(Categoria categoria){
		categoria.setCodigo(sequence++);
		lista.add(categoria);
	}
	
	public List<Categoria> buscarTodos(){
		return lista;
	}
	
	public void remover(int codigo) throws Exception{
		Categoria p = buscarPorCodigo(codigo);
		if (p == null){
			throw new Exception("Produto n�o encontrado");
		}else{
			lista.remove(p);
		}
	}
	
	public void alterar(Categoria categoria) throws Exception{
		Categoria p = buscarPorCodigo(categoria.getCodigo());
		if (p == null){
			throw new Exception("Produto n�o encontrado");
		}else{
			lista.remove(p);
			lista.add(categoria);
		}
	}
	
	public Categoria buscarPorCodigo(int codigo){
		for (Categoria p : lista){
			if (p.getCodigo() == codigo){
				return p;
			}
		}
		return null;
	}
	
}
