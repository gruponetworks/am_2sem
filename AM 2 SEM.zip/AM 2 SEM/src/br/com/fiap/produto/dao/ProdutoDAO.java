package br.com.fiap.produto.dao;

import java.util.ArrayList;
import java.util.List;

import br.com.fiap.produto.bean.Produto;

public class ProdutoDAO {

	private static List<Produto> lista =
			new ArrayList<Produto>();
	
	private static int sequence = 0;
	
	public void cadastrar(Produto produto){
		produto.setCodigo(sequence++);
		lista.add(produto);
	}
	
	public List<Produto> buscarTodos(){
		return lista;
	}
	
	public List<Produto> buscarPorDescricao(String descricao){
		List<Produto> lista = new ArrayList<Produto>();
		for(Produto p: lista){
			if (p.getDescricao().contains(descricao)){
				lista.add(p);
			}
		}
		return lista;
	}
	
	public void remover(int codigo) throws Exception{
		Produto p = buscarPorCodigo(codigo);
		if (p == null){
			throw new Exception("Produto n�o encontrado");
		}else{
			lista.remove(p);
		}
	}
	
	public void alterar(Produto produto) throws Exception{
		Produto p = buscarPorCodigo(produto.getCodigo());
		if (p == null){
			throw new Exception("Produto n�o encontrado");
		}else{
			lista.remove(p);
			lista.add(produto);
		}
	}
	
	public Produto buscarPorCodigo(int codigo){
		for (Produto p : lista){
			if (p.getCodigo() == codigo){
				return p;
			}
		}
		return null;
	}
	
}
