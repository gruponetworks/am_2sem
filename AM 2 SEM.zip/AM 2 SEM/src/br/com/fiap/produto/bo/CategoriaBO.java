package br.com.fiap.produto.bo;

import java.util.List;

import br.com.fiap.produto.bean.Categoria;
import br.com.fiap.produto.dao.CategoriaDAO;

public class CategoriaBO {

	private CategoriaDAO dao = new CategoriaDAO();
	
	public void cadastrar(Categoria p) throws Exception{
		validaCategoria(p);
		dao.cadastrar(p);
	}

	public Categoria buscarPorCodigo(int codigo){
		 return dao.buscarPorCodigo(codigo);
	}
	
	public void alterar(Categoria p) throws Exception{
		validaCategoria(p);
		dao.alterar(p);
	}
	
	public void remover(int codigo) throws Exception{
		dao.remover(codigo);
	}
	
	public List<Categoria> buscarTodos(){
		return dao.buscarTodos();
	}
	
	private void validaCategoria(Categoria p) throws Exception {
		if (p.getTitulo() == null || p.getTitulo().isEmpty())
			throw new Exception("T�tulo � obrigat�rio");
	}
	
}
