package br.com.fiap.produto.servlet;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.fiap.produto.bean.Produto;
import br.com.fiap.produto.bo.ProdutoBO;

@WebServlet("/produtoServlet")
public class ProdutoServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		//Recebe a a��o da p�gina
		String acao = req.getParameter("acao");
		String retorno = "";

		switch (acao) {
		case "cadastrar":
			cadastrar(req);		
			retorno = "cadastro-produto.jsp";
			break;
		case "listar":
			listar(req);
			retorno = "lista-produto.jsp";
			break;		
		case "excluir":
			excluir(req);
			//Recupera a lista atualizada e coloca no request
			listar(req);
			retorno = "lista-produto.jsp";
			break;
		case "carregar":	
			carregar(req);//Carrega um produto para a p�gina JSP
			retorno = "edita-produto.jsp";
			break;
		case "editar":
			try {
				editar(req);
				listar(req);
				retorno = "lista-produto.jsp";
			} catch (Exception e) {
				//Mensagem de erro
				req.setAttribute("erro", e.getMessage());
				carregar(req);
				retorno = "edita-produto.jsp";
			}
		}

		// Redireciona para a p�gina JSP
		req.getRequestDispatcher(retorno).forward(req, resp);
	}

	private void editar(HttpServletRequest req) throws Exception {
		//Recupera os dados do produto
		String desc = req.getParameter("descricao");
		int estoque = Integer.parseInt(req.getParameter("quantidade"));
		double preco = Double.parseDouble(req.getParameter("preco"));
		String cat = req.getParameter("categoria");
		String subCat = req.getParameter("subcategoria");
		
		//recuperar a data
		String data = req.getParameter("data");
		//transformar a string em Calendar
		Calendar dataCadastro = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		//Seta a Data no calendar (String -> Date)
		try {
			dataCadastro.setTime(sdf.parse(data));
		} catch (ParseException e) {
			throw new Exception("Data Inv�lida");
		}
		//Recuperar o c�digo
		int codigo = Integer.parseInt(req.getParameter("codigo"));
		//Cria o Objeto Produto
		Produto produto = 
				new Produto(desc,preco,estoque,cat,subCat,
												dataCadastro);
		produto.setCodigo(codigo);
		//Chama o BO para editar
		ProdutoBO bo = new ProdutoBO();
		bo.alterar(produto);
	}

	private void carregar(HttpServletRequest req) {
		//Recupera o c�digo do produto
		int codigo = Integer.parseInt(req.getParameter("codigo"));
		//Busca o produto no BO
		ProdutoBO bo = new ProdutoBO();
		Produto produto = bo.buscarPorCodigo(codigo);
		//Coloca o produto no request
		req.setAttribute("p", produto);
	}

	private void excluir(HttpServletRequest req) {
		//Recupera o c�digo do produto a ser excluido
		int codigo = Integer.parseInt(req.getParameter("codigo"));
		ProdutoBO bo = new ProdutoBO();
		try {
			//Exclui do banco de dados
			bo.remover(codigo);
			//Mensagem de sucesso
			req.setAttribute("msg","Produto removido!");
		} catch (Exception e) {
			//Mensage de erro
			req.setAttribute("erro", "Produto n�o encontrado!");
		}
	}

	private void listar(HttpServletRequest req) {
		//Buscar todos os produtos cadastrados no banco de dados
		ProdutoBO bo = new ProdutoBO();
		List<Produto> lista = bo.buscarTodos();
		//Setar a lista no request para o JSP
		req.setAttribute("produtos", lista);
	}

	private void cadastrar(HttpServletRequest req) {
		try {
			// Recuperar as informa��es
			String descricao = req.getParameter("descricao");
			int quantidade = Integer.parseInt(req.getParameter("quantidade"));
			double preco = Double.parseDouble(req.getParameter("preco"));
			String categoria = req.getParameter("categoria");
			String subcategoria = req.getParameter("subcategoria");

			// Instanciar o Produto
			Produto produto = new Produto(descricao, preco, quantidade,
					categoria, subcategoria, Calendar.getInstance());
			// Calendar.getInstance() -> Cria um objeto Calendar com a data
			// atual
		
			// Instanciar a Classe de Neg�cio
			ProdutoBO bo = new ProdutoBO();

			bo.cadastrar(produto);
			// Adicionar uma mensagem de sucesso
			req.setAttribute("msg", "Produto Cadastrado!");
		} catch (NumberFormatException nfe){
			//Adicionar uma mensagem de erro
			req.setAttribute("erro", "N�mero Inv�lido");
		} catch (Exception e) {
			// Adicionar a mensagem de erro
			// e.getMessage -> recupera a mensagem de erro configurado no BO
			req.setAttribute("erro", e.getMessage());
		}
	}
}
